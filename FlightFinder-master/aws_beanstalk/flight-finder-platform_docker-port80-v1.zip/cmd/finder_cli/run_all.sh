#!/usr/bin/env bash

go run -gcflags=-B . 