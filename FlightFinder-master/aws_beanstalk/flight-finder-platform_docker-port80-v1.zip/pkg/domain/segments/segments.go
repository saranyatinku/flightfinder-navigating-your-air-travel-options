package segments

// Segments holds mapping id-Segment
type Segments []Segment
