package geo

// Longitude is growing from west to east
type Longitude float32

// Latitude is growing from south to north
type Latitude float32
