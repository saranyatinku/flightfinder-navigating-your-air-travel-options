package pathfinding

// ConnectionID represents a single connection between two nodes
type ConnectionID int32
