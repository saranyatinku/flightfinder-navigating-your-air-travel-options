package pathfinding

// Path represents a sequence of connections that lead from start to goal node
type Path []ConnectionID
