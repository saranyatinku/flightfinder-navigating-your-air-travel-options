package pathfinding

// NodeID is just a unique identifier of actual node that lives in some storage outside to the algorithm
type NodeID int32
